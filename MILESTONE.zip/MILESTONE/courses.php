
<?php
include './includes/header.php';

?>


<!DOCTYPE html>
<html lang="en">
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/IMG-20200404-WA0042.jpg');">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Courses</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Courses <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section><br><br>

    <section class="ftco-section">
			<div class="container-fluid px-4">
				<div class="row">
					<div class="col-md-3 course ftco-animate">
						<div class="img" style="background-image: url(images/IMG-20200401-WA0029.jpg);"></div>
						<div class="text pt-4">
							<!---<p class="meta d-flex">
								<span><i class="icon-user mr-2"></i>Mr. Khan</span>
								<span><i class="icon-table mr-2"></i>10 seats</span>
								<span><i class="icon-calendar mr-2"></i>4 Years</span>
							</p>--->
							<!---<h3><a href="#">Electric Engineering</a></h3>--->
							<p>Separated they live in. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
							<!---<p><a href="#" class="btn btn-primary">Apply now</a></p>---->
						</div>
					</div>
					<div class="col-md-3 course ftco-animate">
						<div class="img" style="background-image: url(images/IMG-20200401-WA0020.jpg);"></div>
						<div class="text pt-4">
							<!---<p class="meta d-flex">
								<span><i class="icon-user mr-2"></i>Mr. Khan</span>
								<span><i class="icon-table mr-2"></i>10 seats</span>
								<span><i class="icon-calendar mr-2"></i>4 Years</span>
							</p>---->
							<!---<h3><a href="#">Electric Engineering</a></h3>--->
							<p>Separated they live in. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
							<!---<p><a href="#" class="btn btn-primary">Apply now</a></p>--->
						</div>
					</div>
					<div class="col-md-3 course ftco-animate">
						<div class="img" style="background-image: url(images/IMG-20200401-WA0030.jpg);"></div>
						<div class="text pt-4">
							<!--<p class="meta d-flex">
								<span><i class="icon-user mr-2"></i>Mr. Khan</span>
								<span><i class="icon-table mr-2"></i>10 seats</span>
								<span><i class="icon-calendar mr-2"></i>4 Years</span>
							</p>---->
							<!----<h3><a href="#">Electric Engineering</a></h3>---->
							<p>Separated they live in. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
							<!---<p><a href="#" class="btn btn-primary">Apply now</a></p>---->
						</div>
					</div>
					<div class="col-md-3 course ftco-animate">
						<div class="img" style="background-image: url(images/IMG-20200401-WA0038.jpg);"></div>
						<div class="text pt-4">
							<!---<p class="meta d-flex">
								<span><i class="icon-user mr-2"></i>Mr. Khan</span>
								<span><i class="icon-table mr-2"></i>10 seats</span>
								<span><i class="icon-calendar mr-2"></i>4 Years</span>
							</p>---->
							<!-----<h3><a href="#">Electric Engineering</a></h3>--->
							<p>Separated they live in. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
							<!---<p><a href="#" class="btn btn-primary">Apply now</a></p>---->
						</div>
					</div>

					<div class="col-md-3 course ftco-animate">
						<div class="img" style="background-image: url(images/IMG-20200401-WA0036.jpg);"></div>
						<div class="text pt-4">
							<!---<p class="meta d-flex">
								<span><i class="icon-user mr-2"></i>Mr. Khan</span>
								<span><i class="icon-table mr-2"></i>10 seats</span>
								<span><i class="icon-calendar mr-2"></i>4 Years</span>
							</p>---->
							<!-----<h3><a href="#">Electric Engineering</a></h3>---->
							<p>Separated they live in. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
							<!-----<p><a href="#" class="btn btn-primary">Apply now</a></p>----->
						</div>
					</div>
					<div class="col-md-3 course ftco-animate">
						<div class="img" style="background-image: url(images/IMG-20200401-WA0037.jpg);"></div>
						<div class="text pt-4">
							<!----<p class="meta d-flex">
								<span><i class="icon-user mr-2"></i>Mr. Khan</span>
								<span><i class="icon-table mr-2"></i>10 seats</span>
								<span><i class="icon-calendar mr-2"></i>4 Years</span>
							</p>----->
							<!---<h3><a href="#">Electric Engineering</a></h3>----->
							<p>Separated they live in. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
							<!-----<p><a href="#" class="btn btn-primary">Apply now</a></p>---->
						</div>
					</div>
					<div class="col-md-3 course ftco-animate">
						<div class="img" style="background-image: url(images/IMG-20200401-WA0035.jpg);"></div>
						<div class="text pt-4">
							<!---<p class="meta d-flex">
								<span><i class="icon-user mr-2"></i>Mr. Khan</span>
								<span><i class="icon-table mr-2"></i>10 seats</span>
								<span><i class="icon-calendar mr-2"></i>4 Years</span>
							</p>------>
							<!----<h3><a href="#">Electric Engineering</a></h3>---->
							<p>Separated they live in. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
							<!----<p><a href="#" class="btn btn-primary">Apply now</a></p>----->
						</div>
					</div>
					<div class="col-md-3 course ftco-animate">
						<div class="img" style="background-image: url(images/course-8.jpg);"></div>
						<div class="text pt-4">
							<!----<p class="meta d-flex">
								<span><i class="icon-user mr-2"></i>Mr. Khan</span>
								<span><i class="icon-table mr-2"></i>10 seats</span>
								<span><i class="icon-calendar mr-2"></i>4 Years</span>
							</p>----->
							<!-----<h3><a href="#">Electric Engineering</a></h3>----->
							<p>Separated they live in. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
							<!----<p><a href="#" class="btn btn-primary">Apply now</a></p>---->
						</div>
					</div>
				</div>
			</div>
		</section>

		
    </body>
</html>


<?php
include './includes/footer.php';

?>