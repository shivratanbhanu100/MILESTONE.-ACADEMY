-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 05, 2020 at 08:58 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `milestone`
--

-- --------------------------------------------------------

--
-- Table structure for table `request_table`
--

DROP TABLE IF EXISTS `request_table`;
CREATE TABLE IF NOT EXISTS `request_table` (
  `id` varchar(11) NOT NULL,
  `firstname` varchar(60) NOT NULL,
  `lastname` varchar(60) NOT NULL,
  `course` varchar(25) NOT NULL,
  `phoneno` int(10) NOT NULL,
  `emailid` varchar(60) NOT NULL,
  `message` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_access`
--

DROP TABLE IF EXISTS `user_access`;
CREATE TABLE IF NOT EXISTS `user_access` (
  `id` int(30) NOT NULL,
  `cat_code` varchar(30) NOT NULL,
  `club_id` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_access`
--

INSERT INTO `user_access` (`id`, `cat_code`, `club_id`) VALUES
(2, 'hsrp', 'T01001'),
(3, 'hsrp', 'T01002'),
(4, 'hsrp', 'T01003'),
(6, 'hsrp', 'T01004'),
(7, 'hsrp', 'T01005'),
(8, 'hsrp', 'T07006'),
(9, 'hsrp', 'T02007'),
(10, 'hsrp', 'T02008'),
(11, 'hsrp', 'T02009'),
(12, 'hsrp', 'T02010'),
(17, 'hsrp', 'T02011'),
(41, 'hsrp', 'T03012'),
(43, 'hsrp', 'T03013'),
(46, 'hsrp', 'T03014'),
(47, 'hsrp', 'T04015'),
(48, 'hsrp', 'T04016'),
(49, 'hsrp', 'T05017'),
(50, 'hsrp', 'T05018'),
(51, 'hsrp', 'T06019'),
(52, 'hsrp', 'T06020'),
(53, 'hsrp', 'T09023'),
(54, 'hsrp', 'T09024'),
(55, 'hsrp', 'T09025'),
(56, 'hsrp', 'T09026'),
(57, 'hsrp', 'T09027'),
(58, 'hsrp', 'T09028'),
(59, 'hsrp', 'T09029'),
(60, 'hsrp', 'T09030'),
(61, 'hsrp', 'T09031'),
(62, 'hsrp', 'T09032'),
(63, 'hsrp', 'T09033'),
(64, 'hsrp', 'T09034'),
(65, 'hsrp', 'T09035'),
(66, 'hsrp', 'T09036'),
(67, 'hsrp', 'T09037'),
(68, 'hsrp', 'T09038');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

DROP TABLE IF EXISTS `user_table`;
CREATE TABLE IF NOT EXISTS `user_table` (
  `user_id` varchar(30) NOT NULL,
  `user_name` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `email` varchar(50) NOT NULL,
  `otp` varchar(10) NOT NULL,
  `nature` varchar(50) NOT NULL,
  `status` int(10) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`user_id`, `user_name`, `password`, `email`, `otp`, `nature`, `status`) VALUES
('U101', 'admin', 'pass', 'email', '', 'customer_master', 1),
('U102', 'test', 'my', 'test@gmail.com', '4660', 'internal_executive', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
